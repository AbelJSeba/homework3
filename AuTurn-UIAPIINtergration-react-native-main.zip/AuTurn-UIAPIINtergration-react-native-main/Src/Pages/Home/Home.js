import React, { useEffect, useState, useRef } from 'react';
import { Animated, View, Text, Image, StyleSheet, SafeAreaView, StatusBar, ImageBackground, TouchableOpacity } from 'react-native';

import CircleButton from "react-native-circle-floatmenu";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import Ionicons from "react-native-vector-icons/Ionicons";
import AntDesign from "react-native-vector-icons/AntDesign";
import Entypo from "react-native-vector-icons/Entypo";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { AnimatedCircularProgress } from 'react-native-circular-progress';
import { CircularProgressbar } from 'react-circular-progressbar';
import { ProgressBar, Colors } from 'react-native-paper';

export default function Home({ route, navigation }) {

    const value = 0.66;
    const percentage = 66;

    return (
        <SafeAreaView style={styles.flexContainer}>
            <StatusBar barStyle={'dark-content'} backgroundColor={'gray'} />
            <View style={styles.mainContainer} backgroundColor={'gray'}>
                <ImageBackground source={require('../../Assets/Imges/bg.png')} style={{ width: '100%', height: '100%' }}>

                    {/* <View >
               <View style={{padding:10}}>

               </View>
             <View style={{paddingBottom:'2%',paddingTop:10}}>
             <Image
        width={100} height={100}
        style={{position:'absolute',right:100}}
        source={require('../../Assets/Imges/ii.png')}
      />
      <Text style={{paddingLeft:'62%'}}>
          ibad
      </Text>
             </View>
             <View style={{paddingBottom:'2%',paddingTop:10}}>
             <Image
        width={100} height={100}
        style={{position:'absolute',right:60}}
        source={require('../../Assets/Imges/ii.png')}
      />
      <Text style={{paddingLeft:'74%'}}>
          ibad
      </Text>
             </View>
             <View style={{paddingBottom:'5%',paddingTop:10}}>
             <Image
        width={100} height={100}
        style={{position:'absolute',right:30}}
        source={require('../../Assets/Imges/ii.png')}
      />
       <Text style={{paddingLeft:'82%'}}>
          ibad
      </Text>
             </View>
             <View style={{paddingTop:'2%'}}>
             <Image
        width={200} height={200}
        style={{position:'absolute',right:10}}
        source={require('../../Assets/Imges/ii.png')}
      />
       <Text style={{paddingLeft:'87%'}}>
          ibad
      </Text>
             </View>
             <View >
             <Image
        width={200} height={200}
        style={{position:'absolute',right:100}}
        source={require('../../Assets/Imges/c.png')}
      />
      <TouchableOpacity onPress={()=>navigation.navigate('Tracking')}>
      <View style={{paddingLeft:'60%',height:'100%'}}>

          <Text style={{paddingTop:20}}>
              Maria
          </Text>
      </View>
      </TouchableOpacity>
      </View>
             </View> */}

                    <View style={styles.btn_container}>
                        <CircleButton buttonColor="#0FBDE1"
                            radius={90}
                            position="topleft"
                            btnOutRange={"#0FBDE1"}
                            icon={<View>
                                <MaterialIcons name={'person-outline'} size={30} />
                                <Text>
                                    Maria
                                </Text>
                            </View>}
                        >
                            <CircleButton.Item


                                position="absolute"
                                buttonColor="#0FBDE1"
                                title="Perfil"
                                onPress={() => console.log("BtnPress")}
                            >
                                <MaterialCommunityIcons name={'account-plus-outline'} size={30} />
                            </CircleButton.Item>
                            <CircleButton.Item

                                position="absolute"
                                buttonColor="#0FBDE1"
                                title="Perfil"
                                onPress={() => navigation.navigate('Tracking')}
                            >
                                <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                                    <MaterialIcons name={'person-outline'} size={18} />
                                    <Text style={{ fontSize: 11 }}>
                                        recent
                                    </Text>
                                </View>
                            </CircleButton.Item>
                            <CircleButton.Item
                                position="absolute"
                                buttonColor="#0FBDE1"

                                title="Perfil"
                                onPress={() => console.log("BtnPress")}
                            >
                                <Ionicons name={"hand-right-outline"} size={30} />
                            </CircleButton.Item>
                            <CircleButton.Item
                                position="absolute"
                                buttonColor="#0FBDE1"
                                title="Perfil"
                                onPress={() => console.log("BtnPress")}
                            >
                                <Ionicons
                                    name="sync-circle"
                                    size={30}
                                    style={{ color: 'black' }}
                                />
                            </CircleButton.Item>


                        </CircleButton>
                    </View>

                    <View style={{ alignItems: 'flex-end', paddingRight: 10 }}>
                        <View style={{ borderWidth: 1, borderRadius: 10, width: 60 }}>
                            <View style={{ justifyContent: 'space-between', flexDirection: 'row', paddingTop: 20,fontSize:10 }}>
                                <Text style={{fontSize:10 }}>
                                    Maria
                                </Text>
                                <AntDesign name="arrowup" size={15} />
                            </View>
                            <View>
                                <Text style={{fontSize:10 }}>
                                    Jone Doe
                                </Text>
                            </View>
                            <View style={{ justifyContent: 'space-between', flexDirection: 'row' }}>
                                <Text style={{fontSize:10 }}>
                                    Luis
                                </Text>

                            </View>
                            <View style={{ justifyContent: 'space-between', flexDirection: 'row', height: 100, paddingTop: 20 }}>
                                <Text>

                                </Text>
                                <AntDesign name="arrowdown" size={15} />
                            </View>
                        </View>

                    </View>
                    <View style={{ alignItems: 'flex-end', paddingRight: 10, width: '70%' }}>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '20%' }}>
                            <Text style={{fontSize:10}}>
                                TILT
                            </Text>
                            <MaterialCommunityIcons name="toggle-switch-off" size={20} color="red" />
                        </View>

                    </View>
                    
                
                    <View style={{ justifyContent: 'center', alignSelf: 'center', padding: 20, }}>
                  
                    <AnimatedCircularProgress
                        size={240}
                        width={25}
                        fill={100}
                        arcSweepAngle={160}
                       rotation={-60}
                        tintColor="#7BCDDF"
                        childrenContainerStyle={{borderRadius:30}}
                        style={{position:'absolute',alignSelf:'center',top:20,left:40,borderRadius:40}}
                        onAnimationComplete={() => console.log('onAnimationComplete')}
                        backgroundColor="#3d5875" />
                        <View style={{ marginLeft: 160 }}>
                            <Image
                                style={{ height: 20, width: 20 }}

                                source={require('../../Assets/Imges/progrescirclebutton.png')}
                            />
                        </View>
                        <View style={{ marginLeft: 60 }}>
                            <Image
                                width={200} height={200}

                                source={require('../../Assets/Imges/device_tilt.png')}
                            />
                        </View>
                        <View style={{ justifyContent: 'space-between', flexDirection: 'row' }}>
                            <Image
                                width={200} height={200}

                                source={require('../../Assets/Imges/arrowleft.png')}
                            />
                            <View style={{ width: '70%', justifyContent: 'center', alignItems: 'center' }}>
                                <Image
                                    width={200} height={200}
                                    style={{ position: 'absolute', right: 25, }}
                                    source={require('../../Assets/Imges/devicebody.png')}
                                />
                                <Text style={{ fontSize: 9 }}>
                                    26%
                                </Text>
                                <FontAwesome name="battery-2" size={20} color="green" />

                            </View>
                            <Image
                                width={200} height={200}

                                source={require('../../Assets/Imges/arrow_right.png')}
                            />
                        </View>
   
                    </View>
                    <View style={{ flexDirection: 'row', justifyContent: 'center', width: '100%', alignItems: 'center', }}>
                        <Text style={{ fontSize: 10 }}>
                            PAN
                        </Text>
                        <MaterialCommunityIcons name="toggle-switch-off" size={25} color="red" />
                    </View>
                    <View style={{width:'70%',marginLeft:50,height:'20%'}}>
                    <ProgressBar progress={1} color={"#7BCDDF"}  style={{height:15,borderRadius:20,position:'absolute'}}/>
                    <View style={{flexDirection:'row',justifyContent:'space-between', width:'95%',height:'60%'}}>
                    <Image
                               style={{width:20,height:15,marginLeft:5}}

                                source={require('../../Assets/Imges/turtlex.png')}
                            />
                            <Image
                                style={{ height: 20, width: 20,marginBottom:20 }}

                                source={require('../../Assets/Imges/progrescirclebuttonx.png')}
                            />
                            <Image
                               style={{width:15,height:15}}

                                source={require('../../Assets/Imges/bunnyx.png')}
                            />
                    </View>
                    </View>
                </ImageBackground>








            </View>
        </SafeAreaView>
    );

}
const styles = StyleSheet.create({
    btn_container: {
        height: '20%',
        marginLeft: '60%',
        width: "100%",

    },
    circleButtonIcon: {
        fontSize: 20,
        height: 22,
        color: "white",
    },
});