import { StyleSheet } from 'react-native';



const styles = StyleSheet.create({
   
    flexContainer: {
        flex: 1,
        backgroundColor: 'white'

    },
    
  
})
export default styles;