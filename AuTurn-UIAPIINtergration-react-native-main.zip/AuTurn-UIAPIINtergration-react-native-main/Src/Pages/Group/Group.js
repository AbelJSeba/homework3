import React, { useEffect, useState, useRef } from 'react';
import { Animated, View, Text, Image, SafeAreaView, StatusBar, ImageBackground, TouchableOpacity } from 'react-native';
import styles from './styles';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Entypo from 'react-native-vector-icons/Entypo';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';




export default function Group({ route, navigation }) {


    return (
        <SafeAreaView style={styles.flexContainer}>
            <StatusBar barStyle={'dark-content'} backgroundColor={'gray'} />
            <View style={styles.mainContainer} backgroundColor={'gray'}>
                <ImageBackground source={require('../../Assets/Imges/bg.png')} style={{ width: '100%', height: '100%' }}>
                    <View style={{ justifyContent: 'center', alignItems: 'center', height: '90%', width: '100%' }}>
                       
                        <View style={{ borderRadius: 100, borderWidth: 1, width: 100, height: 100, justifyContent: 'center', alignItems: 'center' }}>
                            <MaterialIcons name={'people-outline'} size={60} />
                        </View>
                        <View style={{ flexDirection: 'row', padding: 10 }}>
                        <TouchableOpacity style={{ justifyContent: 'center', alignItems: 'center', borderRadius: 20,paddingLeft:10 }}>
                            <View style={{ flexDirection: 'row', padding: 5 }}>
                                <Text style={{fontSize:10}} >
                                    Group Tracking
                                </Text>
                                <MaterialIcons name={'people-outline'} size={15} style={{ paddingLeft: 4 }} />
                            </View>
                        </TouchableOpacity>
                        <Ionicons name={'add-circle-outline'} size={20} style={{ paddingLeft: 2 }} />
                        </View>
                        
                        <Text style={{ padding: 5,fontSize:10 }}>
                            Most recent
                        </Text>
                        <View style={{ flexDirection: 'row', padding: 10 ,width:'80%',justifyContent:'space-around'}}>
                            <View>
                            <View style={{ borderRadius: 100, borderWidth: 1, width: 70, height: 70, justifyContent: 'center', alignItems: 'center' ,}}>
                                <Ionicons name={'person-outline'} size={30} />
                                
                            </View>
                            <View style={{paddingTop:10}}>
                            <Text style={{borderRadius:20,borderWidth:1,textAlign:'center',fontSize:10}}>
                                Recent 1
                            </Text>
                            </View>
                            </View>
                            <View>
                            <View style={{ borderRadius: 100, borderWidth: 1, width: 70, height: 70, justifyContent: 'center', alignItems: 'center' }}>
                                <Ionicons name={'person-outline'} size={30} />
                            </View>
                            <View style={{paddingTop:10}}>
                            <Text style={{borderRadius:20,borderWidth:1,textAlign:'center',fontSize:10}}>
                                Recent 2
                            </Text>
                            </View>
                            </View>
                            <View>
                            <View style={{ borderRadius: 100, borderWidth: 1, width: 70, height: 70, justifyContent: 'center', alignItems: 'center' }}>
                                <Ionicons name={'person-outline'} size={30} />
                            </View>
                            <View style={{paddingTop:10,width:90}}>
                            <Text style={{borderRadius:20,borderWidth:1,textAlign:'center',fontSize:10}}>
                              jhone Doe
                            </Text>
                            </View>
                            </View>
                        </View>
                        <Text>
                            People
                        </Text>
                        <View style={{ flexDirection: 'row', padding: 10 ,width:'100%',justifyContent:'space-around'}}>
                        <View>
                            <View style={{ borderRadius: 100, borderWidth: 1, width: 70, height: 70, justifyContent: 'center', alignItems: 'center' ,}}>
                                <MaterialCommunityIcons name={'account-plus-outline'} size={30} />
                                
                            </View>
                            <View style={{paddingTop:10}}>
                                <TouchableOpacity onPress={()=>navigation.navigate('Profile')}>
                            <Text style={{borderRadius:20,borderWidth:1,textAlign:'center',fontSize:10}}>
                                Add New
                            </Text>
                            </TouchableOpacity>
                            </View>
                            </View>
                            <View>
                            <View style={{ borderRadius: 100, borderWidth: 1, width: 70, height: 70, justifyContent: 'center', alignItems: 'center' ,}}>
                                <Ionicons name={'person-outline'} size={30} />
                                
                            </View>
                            <View style={{paddingTop:10}}>
                            <Text style={{borderRadius:20,borderWidth:1,textAlign:'center',fontSize:10}}>
                                Luis
                            </Text>
                            </View>
                            </View>
                            <View>
                            <View style={{ borderRadius: 100, borderWidth: 1, width: 70, height: 70, justifyContent: 'center', alignItems: 'center' }}>
                                <Ionicons name={'person-outline'} size={30} />
                            </View>
                            <View style={{paddingTop:10}}>
                            <Text style={{borderRadius:20,borderWidth:1,textAlign:'center',fontSize:10}}>
                                Jhon
                            </Text>
                            </View>
                            </View>
                            <View>
                            <View style={{ borderRadius: 100, borderWidth: 1, width: 70, height: 70, justifyContent: 'center', alignItems: 'center' }}>
                                <Ionicons name={'person-outline'} size={30} />
                            </View>
                            <View style={{paddingTop:10,}}>
                            <Text style={{borderRadius:20,borderWidth:1,textAlign:'center',fontSize:10}}>
                              Maria
                            </Text>
                            </View>
                            </View>
                        </View>
                        
                    </View>


                </ImageBackground>








            </View>
        </SafeAreaView>
    );

}
