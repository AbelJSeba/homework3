import React, { useEffect, useState, useRef } from 'react';
import { Animated, View, Text, Image, SafeAreaView, StatusBar, ImageBackground, TouchableOpacity, TextInput } from 'react-native';
import styles from './styles';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Entypo from 'react-native-vector-icons/Entypo';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import AntDesign from 'react-native-vector-icons/AntDesign';




export default function Profile({ route, navigation }) {


    return (
        <SafeAreaView style={styles.flexContainer}>
            <StatusBar barStyle={'dark-content'} backgroundColor={'gray'} />
            <View style={styles.mainContainer} backgroundColor={'gray'}>
                <ImageBackground source={require('../../Assets/Imges/bg.png')} style={{ width: '100%', height: '100%', }}>
                    <View>
                        <Text>
                            
                        </Text>
                    </View>
                    <View style={{  alignItems: 'center', height: '70%', width: '90%',borderRadius:40,borderWidth:1,alignSelf:'center',paddingTop:20 }}>
                        <View style={{flexDirection:'row'}}>
                        <View style={{ borderRadius: 100, borderWidth: 1, width: 70, height: 70, justifyContent: 'center', alignItems: 'center',marginLeft:100 }}>
                            <Ionicons name={'person-outline'} size={30}  />
                           
                        </View>
                        <AntDesign name={'questioncircleo'} size={20}  style={{paddingLeft:20}}/>
                        <Text style={{fontSize:10}}>
                            Instructions
                        </Text>
                        </View>
                       <View style={{padding:10}}>
                        <TouchableOpacity style={{ justifyContent: 'center',alignItems:'center',padding:5,borderWidth:0.5 , borderRadius: 20 }}>
                        
                                <Text  style={{fontSize:10}}>
                                   Take a Profile Photo
                                </Text>
                          
                        </TouchableOpacity>
                        </View>
                        
                      
                      <View style={{flexDirection:'row',width:'100%',alignItems:'center'}}>
                          <View style={{width:'32%',alignItems:'center',height:'40%'}}>
                          <Text style={{fontSize:10,textAlign:'center'}}>
                              Name of Target
                          </Text>
                          </View>
                          <View style={{borderRadius:20,borderWidth:1.4,width:'35%',height:'50%'}}>
                          <TextInput
                          
                          />
                          </View>
                      </View>
                      <View style={{  paddingTop: 10 }}>
                      <TouchableOpacity style={{ justifyContent: 'center', alignItems: 'center',borderWidth:1,borderRadius: 20,padding:10 }}>
                            
                                <Text style={{fontSize:10}}>
                                    Take a video of  target to track(recommanded)
                                </Text>
                              
                            
                        </TouchableOpacity>
                        </View>
                        <View style={{  paddingTop: 10,width:'75%',height:'30%' }}>
                      <TouchableOpacity style={{ borderWidth:1,borderRadius: 20,padding:10 }}>
                            
                                <Text style={{fontSize:10}}>
                                    Take a photo of target to track
                                </Text>
                              
                            
                        </TouchableOpacity>
                        </View>
                       <View style={{flexDirection:'row',justifyContent:'space-around',width:'100%'}}>
                       <TouchableOpacity style={{backgroundColor:'red',borderRadius:10,width:'20%',height:'32%',justifyContent:'center',alignItems:'center'}}>
                            <Text style={{fontSize:10}}>
                                Delete
                            </Text>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={()=>navigation.navigate('Group')} style={{backgroundColor:'green',height:'32%',borderRadius:10,width:'20%',justifyContent:'center',alignItems:'center'}}>
                            <Text style={{fontSize:10}}>
                                Done
                            </Text>
                        </TouchableOpacity>
                       </View>
                    </View>


                </ImageBackground>








            </View>
        </SafeAreaView>
    );

}
