/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Home from './Src/Pages/Home/Home';
import Tracking from './Src/Pages/Tracking/Tracking';
import Profile from './Src/Pages/Profile/Profile';
import Group from './Src/Pages/Group/Group';
const { Navigator, Screen } = createStackNavigator();
const AuthStack = () => (
  <Navigator headerMode='none'>
   
    
     <Screen name='Home' component={Home} />
     <Screen name='Tracking' component={Tracking} />
     <Screen name='Profile' component={Profile} />
     <Screen name='Group' component={Group} />

     
     
       
       
     
  </Navigator>
);
const App = () => (
  <NavigationContainer>
    <AuthStack /> 
  </NavigationContainer>
);

export default App;
